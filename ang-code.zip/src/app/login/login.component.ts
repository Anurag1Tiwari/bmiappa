import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { AuthService } from '../service/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
    constructor(
      private authservice: AuthService
    ){

    }
    model = new User();

    submitted = false;

    validateLogin(form) {
      console.log(form);
      alert("User Name : " + form.controls.userName.value + " User Password : " + form.controls.passPass.value);
      let user = new User();
      user.userName = form.controls.userName.value;
      user.passPass = form.controls.passPass.value;
      this.authservice.login(user).subscribe(
        data=>{},
        error=>{}
      );
      this.submitted = true;

    }


}
