import { Injectable } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../user';

@Injectable({
  providedIn: 'root'
})

export class AuthService {

  constructor(private http: HttpClient) {
  }
  public login(user: User): Observable<any>{
    this.http.post("http://localhost/rest/api/validateLogin.php", user );
  }
  public logout(){

  }
}
