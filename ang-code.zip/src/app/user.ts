export class User {
    public id: number;
    public userName: string;
    public passPass: string;
    public userEmail: string;
  constructor(
    // public id: number,
    // public userName: string,
    // public userPass: string,
    // public userEmail: string
  ) {  }
}
